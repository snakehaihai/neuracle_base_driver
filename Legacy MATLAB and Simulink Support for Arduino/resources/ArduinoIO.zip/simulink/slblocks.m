function blkStruct = slblocks
blkStruct.Name = 'Arduino IO Library';
blkStruct.OpenFcn = 'arduino_io_lib';
blkStruct.MaskInitialization = '';

    %   Copyright 2011 The MathWorks, Inc.